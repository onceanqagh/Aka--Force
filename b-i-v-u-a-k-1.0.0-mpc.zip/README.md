# B I V U A K

An instrument plugin for Akai MPC standalone hardware, by onceanquagh.

_Describe what the plugin does here. This file is included in the distributable zip._

## Build

```
python tools/build.py plugins/B I V U A K
python tools/package.py plugins/B I V U A K
```

## Project layout

- `plugin.json` - manifest (name, manufacturer, uid). The `uid` must match the C++ `uniqueId`.
- `src/BIVUAK.cpp` - the plugin source (parameters, MIDI handling, DSP).
- `ui.json` - which parameters appear on the MPC screen, in which order.
- `build/` - build output (the deployable `onceanquagh - VST - B I V U A K` folder lives here).
- `dist/` - zips produced by `package.py`.
