#include "Karyon8Engine.h"
#include <array>
#include <cmath>
#include <iostream>
int main() {
    karyon8::Engine e; e.prepare(48000.0);
    karyon8::MidiMap map;
    std::array<float,512> l{},r{};
    e.noteOn(36,110,map); e.process(l.data(),r.data(),l.size());
    bool nonzero=false;
    for (std::size_t i=0;i<l.size();++i) nonzero |= std::abs(l[i])+std::abs(r[i])>1.0e-7f;
    e.noteOff(36,map);
    if (!nonzero) { std::cerr << "No audio generated\n"; return 1; }
    std::cout << "KARYON-8 core smoke test passed\n";
    return 0;
}
