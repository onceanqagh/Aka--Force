#pragma once
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>

namespace karyon8 {
constexpr std::size_t kParameterCount = 47;
constexpr std::size_t kVoiceCount = 8;

// MIDI defaults are deliberately configurable: verify the actual Force pad notes.
struct MidiMap {
    std::array<int, kVoiceCount> note {{36, 37, 38, 39, 40, 41, 42, 43}};
};

class Engine {
public:
    Engine();

    void prepare(double sampleRate);
    void reset();

    // Safe to call from a MIDI/event thread. Velocity is 1..127.
    void noteOn(int midiNote, int velocity, const MidiMap& map);
    void noteOff(int midiNote, const MidiMap& map);
    void allNotesOff();

    // Parameter values are normalized [0,1]. Setters are atomic.
    void setParameter(std::size_t index, float value);
    float getParameter(std::size_t index) const;

    // Interleaved-independent stereo processing. Output buffers must not alias.
    void process(float* left, float* right, std::size_t frames);

private:
    struct Voice {
        double phase = 0.0;
        float env = 0.0f, gate = 0.0f, velocity = 0.0f, attack = 0.01f;
        double vibratoPhase = 0.0, vibratoInc = 0.0;
    };

    std::array<std::atomic<float>, kParameterCount> params_;
    std::array<Voice, kVoiceCount> voices_;
    std::array<float, 4> pairOut_ {};
    std::array<float, 4> pairHold_ {};
    std::array<float, 4> pairSharp_ {};
    std::array<float, 4> pairDepth_ {};
    std::array<int, 4> pairSource_ {};
    std::array<bool, 4> pairFast_ {};

    double sr_ = 48000.0;
    std::array<float, 0> unused_ {};
    static constexpr std::size_t kDelayCapacity = 96008;
    std::array<float, kDelayCapacity> delayL_ {}, delayR_ {};
    std::size_t write_ = 0;

    double lfoPhaseA_ = 0.0, lfoPhaseB_ = 0.0;
    float lfoState_ = 0.0f, lastOut_ = 0.0f;
    float delayLP1_ = 0.0f, delayLP2_ = 0.0f;
    float dcXL_ = 0.0f, dcYL_ = 0.0f, dcXR_ = 0.0f, dcYR_ = 0.0f;
    std::uint32_t rng_ = 22222;

    static float clamp(float x, float lo, float hi);
    static float softClip(float x);
    float noise();
    float readDelay(const std::array<float, kDelayCapacity>& buffer, float samples) const;
    int voiceForNote(int note, const MidiMap& map) const;
};
} // namespace karyon8
