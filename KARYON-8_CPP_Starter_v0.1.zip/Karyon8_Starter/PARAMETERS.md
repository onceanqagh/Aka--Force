# Paramètres — index source

Les indices sont conservés tels qu'utilisés dans la simulation HTML.

| Index | Rôle observé dans le code |
|---:|---|
| 0–7 | Accordage des huit voix |
| 8–11 | SHARP des quatre paires |
| 12–15 | Profondeur MOD des quatre paires |
| 16–19 | Source FM des quatre paires |
| 20–23 | Mode FAST des quatre paires |
| 24–25 | PITCH des groupes 1–4 et 5–8 |
| 26–27 | HOLD des groupes 1–4 et 5–8 |
| 28 | Structure FM |
| 29 | Total Feedback |
| 30 | Vibrato |
| 31–32 | Fréquences LFO A et B |
| 33 | Mode AND/OR du LFO |
| 34 | Synchronisation A→B |
| 35–36 | Temps de delay 1 et 2 |
| 37–38 | Modulation du delay 1 et 2 |
| 39 | Source de modulation du delay |
| 40 | Forme/source LFO du delay |
| 41 | Feedback du delay |
| 42 | Mix du delay |
| 43 | Drive |
| 44 | Mix de distorsion |
| 45 | Volume |
| 46 | Bruit / diaphonie |

Cette table décrit les usages visibles dans le HTML. Les unités, valeurs discrètes et
courbes de réponse devront être confirmées lors de la validation DSP.
