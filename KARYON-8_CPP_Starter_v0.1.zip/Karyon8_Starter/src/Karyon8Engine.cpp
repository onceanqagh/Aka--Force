#include "Karyon8Engine.h"
#include <algorithm>
#include <cmath>

namespace karyon8 {
namespace {
constexpr double kPi2 = 6.2831853071795864769;
constexpr std::array<double, 8> kLow {{16,16,40,40,80,80,80,80}};
constexpr std::array<double, 8> kHigh{{700,700,2800,2800,5600,5600,5600,5600}};
constexpr std::array<double, 8> kDefaultHz{{55,82.41,110,130.81,164.81,220,329.63,440}};
float normalizedTune(std::size_t i) {
    return static_cast<float>(std::log(kDefaultHz[i] / kLow[i]) /
                              std::log(kHigh[i] / kLow[i]));
}
}

float Engine::clamp(float x, float lo, float hi) {
    return std::max(lo, std::min(hi, x));
}
float Engine::softClip(float x) {
    if (x > 3.0f) return 1.0f;
    if (x < -3.0f) return -1.0f;
    return x * (27.0f + x*x) / (27.0f + 9.0f*x*x);
}
float Engine::noise() {
    rng_ = rng_ * 1664525u + 1013904223u;
    return static_cast<float>(static_cast<std::int32_t>(rng_)) / 2147483648.0f;
}

Engine::Engine() {
    for (std::size_t i=0; i<kParameterCount; ++i) params_[i].store(0.0f);
    for (std::size_t i=0; i<8; ++i) params_[i].store(normalizedTune(i));
    for (std::size_t i=8; i<12; ++i) params_[i].store(0.5f);
    for (std::size_t i=24; i<26; ++i) params_[i].store(1.0f);
    params_[31].store(0.5f); params_[32].store(0.4f);
    params_[35].store(0.62f); params_[36].store(0.7f);
    params_[41].store(0.3f); params_[42].store(0.35f);
    params_[43].store(0.25f); params_[45].store(0.7f); params_[46].store(0.25f);
    prepare(48000.0);
}
void Engine::prepare(double sampleRate) {
    sr_ = std::max(8000.0, sampleRate);
    reset();
}
void Engine::reset() {
    voices_ = {};
    pairOut_ = {}; pairHold_ = {};
    delayL_.fill(0.0f); delayR_.fill(0.0f); write_ = 0;
    lfoPhaseA_=lfoPhaseB_=0.0; lfoState_=lastOut_=0.0f;
    delayLP1_=delayLP2_=dcXL_=dcYL_=dcXR_=dcYR_=0.0f;
    for (std::size_t i=0; i<8; ++i) {
        voices_[i].vibratoPhase = 0.13 * static_cast<double>(i);
        voices_[i].vibratoInc = (3.7 + 0.43 * static_cast<double>(i)) / sr_;
    }
}
void Engine::setParameter(std::size_t i, float v) {
    if (i < kParameterCount) params_[i].store(clamp(v, 0.0f, 1.0f), std::memory_order_relaxed);
}
float Engine::getParameter(std::size_t i) const {
    return i < kParameterCount ? params_[i].load(std::memory_order_relaxed) : 0.0f;
}
int Engine::voiceForNote(int note, const MidiMap& map) const {
    for (int i=0; i<8; ++i) if (map.note[static_cast<std::size_t>(i)] == note) return i;
    return -1;
}
void Engine::noteOn(int note, int velocity, const MidiMap& map) {
    const int v = voiceForNote(note, map);
    if (v < 0) return;
    auto& voice = voices_[static_cast<std::size_t>(v)];
    voice.gate = 1.0f;
    voice.velocity = clamp(static_cast<float>(velocity) / 127.0f, 0.0f, 1.0f);
    const float attackSeconds = 0.3f * std::pow(0.013f, voice.velocity);
    voice.attack = 1.0f - std::exp(-1.0f / (attackSeconds * static_cast<float>(sr_)));
}
void Engine::noteOff(int note, const MidiMap& map) {
    const int v = voiceForNote(note, map);
    if (v >= 0) voices_[static_cast<std::size_t>(v)].gate = 0.0f;
}
void Engine::allNotesOff() {
    for (auto& v : voices_) v.gate = 0.0f;
}
float Engine::readDelay(const std::array<float, kDelayCapacity>& b, float samples) const {
    const float cap = static_cast<float>(kDelayCapacity - 4);
    float pos = static_cast<float>(write_) - clamp(samples, 4.0f, cap);
    while (pos < 0.0f) pos += static_cast<float>(kDelayCapacity);
    const auto i = static_cast<std::size_t>(pos);
    const auto j = (i + 1) % kDelayCapacity;
    const float frac = pos - static_cast<float>(i);
    return b[i] + frac * (b[j] - b[i]);
}

void Engine::process(float* left, float* right, std::size_t frames) {
    if (!left || !right) return;
    // Snapshot parameters once per block; the audio loop does not allocate or lock.
    float p[47]; for (std::size_t i=0; i<47; ++i) p[i]=params_[i].load(std::memory_order_relaxed);
    double base[8];
    const double pitchA = std::pow(2.0, -(1.0-p[24])*2.0);
    const double pitchB = std::pow(2.0, -(1.0-p[25])*2.0);
    for (int i=0; i<8; ++i) {
        const double norm = kLow[i] * std::pow(kHigh[i]/kLow[i], p[i]);
        base[i] = norm * ((i < 4) ? pitchA : pitchB);
    }
    const bool structure = p[28] > .5f, totalFb = p[29] > .5f, vibrato = p[30] > .5f;
    for (int q=0; q<4; ++q) {
        pairSource_[q] = static_cast<int>(std::lround(p[16+q]*2.0f));
        pairDepth_[q] = 1800.0f*p[12+q]*p[12+q];
        pairFast_[q] = p[20+q] > .5f;
        pairSharp_[q] = p[8+q];
        const float h = p[q < 2 ? 26 : 27];
        pairHold_[q] = h*h;
    }
    const bool andMode = p[33] > .5f, linked = p[34] > .5f;
    const double fA=.05*std::pow(1200.0,p[31]), fB0=.05*std::pow(1200.0,p[32]);
    const float time1=.003f*std::pow(300.0f,p[35]), time2=.003f*std::pow(300.0f,p[36]);
    const float mod1=p[37], mod2=p[38], feedback=p[41]*1.8f, mix=p[42];
    const float drive=1.0f+39.0f*p[43], distMix=p[44], volume=p[45]*p[45]*2.0f, nz=p[46];
    const float lpCoeff=1.0f-std::exp(static_cast<float>(-kPi2*5500.0/sr_));
    const float lfoCoeff=1.0f-std::exp(static_cast<float>(-kPi2*120.0/sr_));
    const float releaseSlow=1.0f-std::exp(static_cast<float>(-1.0/(1.4*sr_)));
    const float releaseFast=1.0f-std::exp(static_cast<float>(-1.0/(.06*sr_)));
    const int pairRoute[4] = { structure ? 3 : 1, 0, structure ? 1 : 3, 2 };
    float t1=time1, t2=time2;

    for (std::size_t s=0; s<frames; ++s) {
        lfoPhaseA_ += fA/sr_; lfoPhaseA_ -= std::floor(lfoPhaseA_);
        const float triA=static_cast<float>(1.0-4.0*std::abs(lfoPhaseA_-.5));
        lfoPhaseB_ += (linked ? fB0*(1.0+.6*triA) : fB0)/sr_;
        lfoPhaseB_ -= std::floor(lfoPhaseB_);
        const float sqA=lfoPhaseA_<.5?1.0f:0.0f, sqB=lfoPhaseB_<.5?1.0f:0.0f;
        const float raw=andMode ? sqA*sqB : .5f*(sqA+sqB);
        lfoState_ += lfoCoeff*((raw*2.0f-1.0f)-lfoState_);
        const float triB=static_cast<float>(1.0-4.0*std::abs(lfoPhaseB_-.5));
        const float tri=.5f*(triA+triB), lfo=totalFb?lastOut_:lfoState_;

        float sum=0.0f, waveSum=0.0f;
        float voiceSample[8]{};
        for (int i=0; i<8; ++i) {
            auto& v=voices_[static_cast<std::size_t>(i)];
            const int q=i>>1;
            double freq=base[i];
            if (vibrato) {
                v.vibratoPhase += v.vibratoInc; v.vibratoPhase -= std::floor(v.vibratoPhase);
                freq *= 1.0 + .006*(1.0-4.0*std::abs(v.vibratoPhase-.5));
            }
            freq *= 1.0 + .004*(v.env-.5f);
            if (pairSource_[q] == 1) freq += pairDepth_[q]*pairOut_[pairRoute[q]];
            else if (pairSource_[q] >= 2) freq += pairDepth_[q]*lfo;
            freq=clamp(static_cast<float>(freq), static_cast<float>(-0.45*sr_), static_cast<float>(0.45*sr_));
            v.phase += freq/sr_; v.phase -= std::floor(v.phase);
            const float triangle=static_cast<float>(1.0-4.0*std::abs(v.phase-.5));
            const float shape=1.0f+14.0f*clamp(pairSharp_[q]+.12f*v.env,0.0f,1.0f);
            const float wave=softClip(shape*triangle)/softClip(shape);
            const float target=std::max(v.gate*v.velocity, pairHold_[q]);
            const float coeff=(target>v.env)?(v.gate>0.0f?v.attack:.002f):(pairFast_[q]?releaseFast:releaseSlow);
            v.env += coeff*(target-v.env);
            const float out=wave*v.env;
            voiceSample[i]=out;
            sum+=out; waveSum+=wave;
        }
        for (int q=0; q<4; ++q) {
            const int a=q*2, b=a+1;
            // The original prototype feeds the mean of each voice pair to the FM bus.
            pairOut_[q]=.5f*(voiceSample[a] + voiceSample[b]);
        }
        const float dry=.16f*sum + nz*.0012f*waveSum + nz*.0015f*noise();
        t1 += .0008f*(time1-t1); t2 += .0008f*(time2-t2);
        const float source1=(p[39]>.5f)?(totalFb?lastOut_:lfo):(p[40]<.5f?tri:lfo);
        const float source2=source1;
        const float d1=readDelay(delayL_, static_cast<float>(sr_)*clamp(t1*(1.0f+mod1*.9f*source1),4.0f,static_cast<float>(kDelayCapacity-6)/static_cast<float>(sr_)));
        const float d2=readDelay(delayR_, static_cast<float>(sr_)*clamp(t2*(1.0f+mod2*.9f*source2),4.0f,static_cast<float>(kDelayCapacity-6)/static_cast<float>(sr_)));
        delayLP1_ += lpCoeff*(d1-delayLP1_); delayLP2_ += lpCoeff*(d2-delayLP2_);
        delayL_[write_]=softClip(dry+feedback*(.65f*delayLP1_+.35f*delayLP2_)+nz*.002f*noise());
        delayR_[write_]=softClip(dry+feedback*(.65f*delayLP2_+.35f*delayLP1_)+nz*.002f*noise());
        write_=(write_+1)%kDelayCapacity;
        float l=dry*(1.0f-mix)+d1*mix*1.2f;
        float r=dry*(1.0f-mix)+d2*mix*1.2f;
        l=(l*(1.0f-distMix)+.7f*softClip(drive*l)*distMix)*volume;
        r=(r*(1.0f-distMix)+.7f*softClip(drive*r)*distMix)*volume;
        const float yl=l-dcXL_+.995f*dcYL_; dcXL_=l; dcYL_=yl;
        const float yr=r-dcXR_+.995f*dcYR_; dcXR_=r; dcYR_=yr;
        left[s]=softClip(yl); right[s]=softClip(yr);
        lastOut_=.5f*(left[s]+right[s]);
    }
}
} // namespace karyon8
