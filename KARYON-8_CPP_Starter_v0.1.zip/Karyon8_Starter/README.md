# KARYON-8 — moteur audio C++ (socle v0.1)

Ce dépôt est le premier socle C++ issu de la simulation HTML fournie. Il ne constitue
pas encore un plugin VST2 ni un binaire installable sur Akai Force.

## Contenu
- Moteur stéréo C++17 sans dépendance externe.
- 47 paramètres normalisés (indices conservés de 0 à 46).
- 8 voix et réception Note On / Note Off.
- Mapping MIDI configurable ; valeurs par défaut provisoires : notes 36 à 43.
- Traitement audio sans allocation ni verrou dans `process()`.
- Test minimal de génération audio.

## Compilation sur ordinateur

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

## Mapping des pads
Le mapping par défaut 36–43 est une convention de départ, PAS une mesure des notes
réellement émises par l'Akai Force. Il faudra relever les notes MIDI de chaque pad
sur la Force et remplir `MidiMap::note` en conséquence.

## État / limites à traiter avant une version jouable
1. Valider par écoute et mesures la parité DSP avec le prototype JavaScript.
2. Le portage conserve les familles d'algorithmes, mais certains détails restent à
   vérifier : modulation FM par paires, sources de delay, comportement exact des
   paramètres discrets et enveloppes.
3. Ajouter la couche hôte (MIDI, automation, sauvegarde d'état, presets) et une
   interface graphique native compatible avec le chargeur ciblé.
4. Vérifier l'architecture CPU, l'ABI, le SDK et les contraintes exactes du système
   de plugins installé sur la Force avant toute compilation cible.
5. Ne jamais faire tourner de dessin ou d'animation dans le thread audio.

## Convention de paramètres
Les paramètres sont accessibles par index stable `0..46`. Les valeurs sont normalisées
dans `[0,1]`. La table descriptive et les plages exactes doivent être extraites et
documentées avant d'exposer les contrôles dans l'interface.
